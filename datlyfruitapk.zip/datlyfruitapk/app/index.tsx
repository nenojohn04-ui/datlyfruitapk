import React, { useState } from "react";

import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TextInput,
  TouchableOpacity,
  StatusBar,
} from "react-native";




import CartScreen from "./CartScreen";
import { Ionicons, MaterialCommunityIcons } from "@expo/vector-icons";
import WalmartScreen from "./WalmartScreen";
import { useRouter } from "expo-router";
type NavKey = "HOME" | "CATEGORIES" | "ORDERS" | "CART" | "PROFILE";

const quickFilters = [
  "Tümü",
  "İndirimdekiler",
  "En çok satan",
  "Yeni gelenler",
  "Kahvaltılık",
];

const categories = [
  { id: "1", name: "Meyve", emoji: "🍎", color: "#FDECEF" },
  { id: "2", name: "Sebze", emoji: "🥦", color: "#E8F7ED" },
  { id: "3", name: "İçecek", emoji: "🥤", color: "#E7F1FF" },
  { id: "4", name: "Süt & Kahvaltı", emoji: "🥛", color: "#FFF4E1" },
  { id: "5", name: "Atıştırmalık", emoji: "🍫", color: "#F5E8FF" },
  { id: "6", name: "Temizlik", emoji: "🧴", color: "#E9F7FF" },
];

const curatedBundles = [
  {
    id: "b1",
    title: "Haftalık Meyve Sepeti",
    desc: "Elma, muz, üzüm, kivi – 4 kişilik aile",
    badge: "%25 İndirim",
    price: "189,90 ₺",
    time: "Bugün 20:00’a kadar",
  },
  {
    id: "b2",
    title: "Premium Kahvaltı Kutusu",
    desc: "Peynir, zeytin, yumurta, bal, tereyağı",
    badge: "Favori",
    price: "229,90 ₺",
    time: "Yarın sabah 09:00",
  },
];

const bestSellers = [
  {
    id: "p1",
    name: "Fuji Elma 1kg",
    info: "Sulu & tatlı",
    price: "49,90 ₺",
    badge: "Çok satan",
    emoji: "🍎",
  },
  {
    id: "p2",
    name: "Muz 1kg",
    info: "Her gün taze",
    price: "59,90 ₺",
    badge: "Kampanyalı",
    emoji: "🍌",
  },
  {
    id: "p3",
    name: "Salkım Domates 1kg",
    info: "Seradan sofraya",
    price: "39,90 ₺",
    badge: "Günün ürünü",
    emoji: "🍅",
  },
  {
    id: "p4",
    name: "Günlük Süt 1L",
    info: "Soğuk zincir",
    price: "24,90 ₺",
    badge: "Popüler",
    emoji: "🥛",
  },
];

const quickActions = [
  { id: "qa1", label: "Haftalık alışveriş", icon: "calendar-outline" },
  { id: "qa2", label: "Son sipariş", icon: "time-outline" },
  { id: "qa3", label: "Favorilerim", icon: "heart-outline" },
];

export default function HomeScreen() {
  const [activeNav, setActiveNav] = useState("HOME");
  const router = useRouter();  
  // CATALOG butonu → Walmart Screen’e geçiş
if (activeNav === "CATEGORIES") {
  return <WalmartScreen />;
}

// CART →
if (activeNav === "CART") {
  return <CartScreen onBack={() => setActiveNav("HOME")} />;
}


  return (
    <View style={styles.root}>
      <StatusBar barStyle="dark-content" backgroundColor="#F5F7FB" />
      {/* ANA CONTAINER */}
      <View style={styles.container}>
        {/* HEADER */}

{/* ULTRA PREMIUM APPLE HEADER */}
<View style={styles.appleHeaderPro}>

  {/* TOP TITLE */}
  <Text style={styles.topTitle}>DatlyFruit</Text>

  {/* DELIVERY SUBTEXT */}
  <View style={styles.subRow}>
    <MaterialCommunityIcons
      name="lightning-bolt-outline"
      size={18}
      color="#0B63CE"
    />
    <Text style={styles.subText}>Online Delivery • 15–30 dk</Text>
  </View>

  {/* ADDRESS SELECTOR */}
  <TouchableOpacity style={styles.addressCard}>
    <Ionicons name="location-outline" size={20} color="#0B63CE" />
   <Text style={styles.appleAddressText} numberOfLines={1}>
  İstanbul, Kadıköy
</Text>

    <Ionicons name="chevron-down" size={18} color="#7C8AA3" />
  </TouchableOpacity>

  {/* NOTIFICATION ICON */}
  <TouchableOpacity style={styles.notifButton}>
    <Ionicons name="notifications-outline" size={24} color="#0B63CE" />
    <View style={styles.notifDot} />
  </TouchableOpacity>

</View>













        {/* KART: TESLİMAT ÖZETİ */}
        <View style={styles.deliveryCard}>
          <View style={styles.deliveryLeft}>
            <Text style={styles.deliveryTitle}>Teslimat Planı</Text>
            <Text style={styles.deliveryLine}>
              Bugün <Text style={styles.deliveryHighlight}>19:00 - 20:00</Text>
            </Text>
            <Text style={styles.deliverySub}>
              150 ₺ üzeri siparişlerde teslimat ÜCRETSİZ.
            </Text>
            <View style={styles.deliveryTagRow}>
              <View style={[styles.deliveryTag, { backgroundColor: "#E3F2FF" }]}>
                <Ionicons name="shield-checkmark-outline" size={14} color="#0B63CE" />
                <Text style={styles.deliveryTagText}>Soğuk zincir</Text>
              </View>
              <View style={[styles.deliveryTag, { backgroundColor: "#E6F5EC" }]}>
                <Ionicons name="leaf-outline" size={14} color="#148142" />
                <Text style={styles.deliveryTagText}>Günlük tedarik</Text>
              </View>
            </View>
          </View>

          <View style={styles.deliveryRight}>
            <View style={styles.deliveryCircleOuter}>
              <View style={styles.deliveryCircleInner}>
                <Ionicons name="bus-outline" size={26} color="#0B63CE" />
              </View>
            </View>
            <Text style={styles.deliveryEta}>Tahmini • 24 dk</Text>
          </View>
        </View>

        {/* ARAMA ALANI */}
  

        {/* HIZLI FİLTRELER */}


        {/* SCROLLABLE CONTENT */}
        <ScrollView
          style={styles.scroll}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingBottom: 96 }}
        >
          {/* HIZLI AKSİYONLAR */}
       

          {/* KATEGORİLER */}
 

          {/* ÖZEL SEPETLER */}
          <View style={styles.sectionBlock}>
            <View style={styles.sectionHeaderRow}>
              <Text style={styles.sectionTitle}>Sana özel sepetler</Text>
              <Text style={styles.sectionLink}>Önerileri yenile</Text>
            </View>

            {curatedBundles.map((bundle) => (
              <TouchableOpacity key={bundle.id} style={styles.bundleCard}>
                <View style={styles.bundleLeft}>
                  <View style={styles.bundleTag}>
                    <Ionicons
                      name="sparkles-outline"
                      size={14}
                      color="#0B63CE"
                      style={{ marginRight: 4 }}
                    />
                    <Text style={styles.bundleTagText}>{bundle.badge}</Text>
                  </View>
                  <Text style={styles.bundleTitle}>{bundle.title}</Text>
                  <Text style={styles.bundleDesc}>{bundle.desc}</Text>
                  <View style={styles.bundleMetaRow}>
                    <View style={styles.bundleTimePill}>
                      <Ionicons name="time-outline" size={14} color="#667085" />
                      <Text style={styles.bundleTimeText}>{bundle.time}</Text>
                    </View>
                    <Text style={styles.bundlePrice}>{bundle.price}</Text>
                  </View>
                </View>
                <View style={styles.bundleRight}>
                  <View style={styles.bundleCircleBig} />
                  <View style={styles.bundleCircleSmall} />
                  <Text style={styles.bundleEmoji}>🍇🍓🍊</Text>
                </View>
              </TouchableOpacity>
            ))}
          </View>

          {/* EN ÇOK SATANLAR */}
          <View style={styles.sectionBlock}>
            <View style={styles.sectionHeaderRow}>
              <Text style={styles.sectionTitle}>En çok satanlar</Text>
              <Text style={styles.sectionLink}>Tüm liste</Text>
            </View>

            {bestSellers.map((item, index) => (
              <View key={item.id}>
                <View style={styles.productRow}>
                  <View style={styles.productLeft}>
                    <View style={styles.productEmojiCircle}>
                      <Text style={styles.productEmoji}>{item.emoji}</Text>
                    </View>
                    <View>
                      <Text style={styles.productName}>{item.name}</Text>
                      <View style={styles.productMetaRow}>
                        <Text style={styles.productInfo}>{item.info}</Text>
                        <View style={styles.productBadge}>
                          <Ionicons
                            name="flame-outline"
                            size={12}
                            color="#B54708"
                          />
                          <Text style={styles.productBadgeText}>
                            {item.badge}
                          </Text>
                        </View>
                      </View>
                    </View>
                  </View>
                  <View style={styles.productRight}>
                    <Text style={styles.productPrice}>{item.price}</Text>
                    <TouchableOpacity style={styles.productAddButton}>
                      <Ionicons
                        name="add"
                        size={16}
                        color="#FFFFFF"
                        style={{ marginRight: 2 }}
                      />
                      <Text style={styles.productAddText}>Add</Text>
                    </TouchableOpacity>
                  </View>
                </View>
                {index !== bestSellers.length - 1 && (
                  <View style={styles.productDivider} />
                )}
              </View>
            ))}
          </View>

          {/* ALT BİLGİ */}
          <View style={styles.footerCard}>
            <Text style={styles.footerTitle}>DatlyFruit Güvencesi</Text>
            <Text style={styles.footerText}>
              Israfı azaltan tedarik zinciri, soğuk zincir teslimat ve saniyeler
              içinde destek. Her siparişin arkasında DatlyFruit var.
            </Text>
            <View style={styles.footerPillsRow}>
              <View style={styles.footerPill}>
                <Ionicons name="snow-outline" size={14} color="#155EEF" />
                <Text style={styles.footerPillText}>Soğuk zincir</Text>
              </View>
              <View style={styles.footerPill}>
                <Ionicons name="shield-checkmark-outline" size={14} color="#155EEF" />
                <Text style={styles.footerPillText}>İade garantisi</Text>
              </View>
              <View style={styles.footerPill}>
                <Ionicons name="chatbubble-ellipses-outline" size={14} color="#155EEF" />
                <Text style={styles.footerPillText}>7/24 destek</Text>
              </View>
            </View>
          </View>
        </ScrollView>
      </View>

      {/* BOTTOM NAVIGATION BAR */}
   <View style={styles.bottomNav}>
  <NavItem
    label="Home"
    icon="home-outline"
    activeIcon="home"
    active={activeNav === "HOME"}
    onPress={() => setActiveNav("HOME")}
  />
<NavItem
  label="Catalog"
  icon="grid-outline"
  activeIcon="grid"
  active={activeNav === "CATEGORIES"}
  onPress={() => setActiveNav("CATEGORIES")}
/>


<NavItem
  label="Orders"
  icon="receipt-outline"
  activeIcon="receipt"
  active={activeNav === "ORDERS"}
  onPress={() => router.push("/OrdersScreen")}
/>




  <NavItem
    label="Cart"
    icon="cart-outline"
    activeIcon="cart"
    active={activeNav === "CART"}
    onPress={() => setActiveNav("CART")}
  />
  <NavItem
    label="Profile"
    icon="person-outline"
    activeIcon="person"
    active={activeNav === "PROFILE"}
    onPress={() => setActiveNav("PROFILE")}
  />
</View>

    </View>
  );
}

type NavItemProps = {
  label: string;
  icon: string;
  activeIcon: string;
  active: boolean;
  onPress: () => void;
};

function NavItem({ label, icon, activeIcon, active, onPress }: NavItemProps) {
  return (
    <TouchableOpacity style={styles.navItem} onPress={onPress} activeOpacity={0.9}>
      <Ionicons
        name={(active ? activeIcon : icon) as any}
        size={22}
        color={active ? "#0B63CE" : "#98A2B3"}
      />
      <Text style={[styles.navLabel, active && styles.navLabelActive]}>{label}</Text>
      {active && <View style={styles.navIndicator} />}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: "#F5F7FB",
  },
container: {
  flex: 1,
  paddingHorizontal: 0, 
  paddingTop: 0,
},

headerRow: {
  flexDirection: "row",
  justifyContent: "space-between",
  alignItems: "center",   // ← en önemli düzeltme!
  marginBottom: 12,
  marginTop: 6,
},

logoBlock: {
  flexDirection: "column",
  justifyContent: "center",
},

  logoText: {
    fontSize: 26,
    fontWeight: "900",
    color: "#0B63CE",
    letterSpacing: 0.2,
  },
  logoSubRow: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 4,
  },
  logoSubText: {
    fontSize: 12,
    color: "#7C8AA3",
    marginLeft: 4,
  },
  headerRight: {
    flexDirection: "row",
    alignItems: "center",
  },
addressPill: {
  flexDirection: "row",
  alignItems: "center",
  backgroundColor: "#E6F0FF",
  borderRadius: 999,
  paddingHorizontal: 10,
  paddingVertical: 4,
  maxWidth: 140,
  flexShrink: 1,     // ← EN ÖNEMLİ SATIR
  marginRight: 6,
},


addressText: {
  fontSize: 15,
  fontWeight: "600",
  color: "#0B63CE",
  marginHorizontal: 8,
  flex: 1,
  textAlign: "center",
},

iconBadge: {
  width: 32,
  height: 32,
  borderRadius: 16,
  backgroundColor: "#FFFFFF",
  borderWidth: 1,
  borderColor: "#E0E4F0",
  justifyContent: "center",
  alignItems: "center",
  marginLeft: 4,
},

  iconDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: "#F97316",
    position: "absolute",
    top: 6,
    right: 6,
  },
  deliveryCard: {
    flexDirection: "row",
    justifyContent: "space-between",
    backgroundColor: "#FFFFFF",
    borderRadius: 18,
    padding: 14,
    marginBottom: 14,
    shadowColor: "#000",
    shadowOpacity: 0.05,
    shadowOffset: { width: 0, height: 4 },
    shadowRadius: 10,
    elevation: 3,
  },
  deliveryLeft: {
    flex: 1.4,
  },
  deliveryTitle: {
    fontSize: 14,
    fontWeight: "700",
    color: "#1C2439",
    marginBottom: 4,
  },
  deliveryLine: {
    fontSize: 13,
    color: "#4B5563",
  },
  deliveryHighlight: {
    fontWeight: "700",
    color: "#0B63CE",
  },
  deliverySub: {
    fontSize: 11,
    color: "#7C8AA3",
    marginTop: 6,
  },
  deliveryTagRow: {
    flexDirection: "row",
    marginTop: 8,
  },
  deliveryTag: {
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 999,
    paddingHorizontal: 8,
    paddingVertical: 4,
    marginRight: 8,
  },
  deliveryTagText: {
    fontSize: 11,
    marginLeft: 4,
    color: "#1C2439",
  },
  deliveryRight: {
    alignItems: "center",
    justifyContent: "center",
    flex: 0.9,
  },
  deliveryCircleOuter: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: "#E6F0FF",
    justifyContent: "center",
    alignItems: "center",
  },
  deliveryCircleInner: {
    width: 42,
    height: 42,
    borderRadius: 21,
    backgroundColor: "#FFFFFF",
    justifyContent: "center",
    alignItems: "center",
  },
  deliveryEta: {
    fontSize: 11,
    color: "#7C8AA3",
    marginTop: 4,
  },
  searchRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 8,
  },
  searchBox: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#FFFFFF",
    borderRadius: 999,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderWidth: 1,
    borderColor: "#E1E5F0",
  },
  searchInput: {
    flex: 1,
    marginLeft: 6,
    fontSize: 13,
    color: "#1C2439",
  },
  filterButton: {
    marginLeft: 8,
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: "#E6F0FF",
    justifyContent: "center",
    alignItems: "center",
  },
  filterScroll: {
    paddingVertical: 6,
  },
  filterChip: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 999,
    backgroundColor: "#E5E7EB",
    marginRight: 8,
  },
  filterChipActive: {
    backgroundColor: "#0B63CE",
  },
  filterText: {
    fontSize: 12,
    color: "#4B5563",
  },
  filterTextActive: {
    color: "#FFFFFF",
    fontWeight: "600",
  },
  scroll: {
    flex: 1,
  },
sectionBlock: {
  marginTop: 8,
  paddingHorizontal: 16,   // ← ÜRÜN LİSTESİNİ TAM İÇE ALIR
},

 sectionHeaderRow: {
  flexDirection: "row",
  justifyContent: "space-between",
  alignItems: "center",
  marginBottom: 8,
  paddingHorizontal: 12,   // ← YAZILARI İÇE ALIR!
},

  sectionTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: "#111827",
  },
  sectionLink: {
    fontSize: 12,
    color: "#0B63CE",
  },
  quickRow: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  quickCard: {
    flex: 1,
    marginRight: 8,
    backgroundColor: "#FFFFFF",
    borderRadius: 14,
    paddingVertical: 10,
    paddingHorizontal: 8,
    borderWidth: 1,
    borderColor: "#E1E5F0",
  },
  quickIconCircle: {
    width: 26,
    height: 26,
    borderRadius: 13,
    backgroundColor: "#E6F0FF",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 6,
  },
  quickText: {
    fontSize: 12,
    color: "#374151",
  },
  categoryGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
  },
categoryCard: {
  width: "30%",               // ← daha geniş
  borderRadius: 18,           
  paddingVertical: 14,        // ← içeriden geniş
  paddingHorizontal: 10,
  backgroundColor: "#FFFFFF",
  alignItems: "center",
  justifyContent: "center",
  marginBottom: 12,
  shadowColor: "#000",
  shadowOpacity: 0.05,
  shadowRadius: 8,
  elevation: 3,
},

categoryEmojiCircle: {
  width: 58,
  height: 58,
  borderRadius: 29,
  backgroundColor: "#F2F6FF",
  justifyContent: "center",
  alignItems: "center",

  shadowColor: "#000",
  shadowOpacity: 0.08,
  shadowRadius: 12,
  shadowOffset: { width: 0, height: 3 },
},

  categoryEmoji: {
    fontSize: 30,
  },
  categoryName: {
    fontSize: 12,
    fontWeight: "600",
    color: "#111827",
  },
  bundleCard: {
    flexDirection: "row",
    backgroundColor: "#FFFFFF",
    borderRadius: 18,
    padding: 14,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: "#E1E5F0",
  },
  bundleLeft: {
    flex: 1.5,
  },
  bundleRight: {
    flex: 0.9,
    justifyContent: "center",
    alignItems: "center",
    position: "relative",
  },
  bundleTag: {
    flexDirection: "row",
    alignItems: "center",
    alignSelf: "flex-start",
    backgroundColor: "#E0EDFF",
    borderRadius: 999,
    paddingHorizontal: 8,
    paddingVertical: 3,
    marginBottom: 6,
  },
  bundleTagText: {
    fontSize: 11,
    color: "#0B63CE",
    fontWeight: "600",
  },
  bundleTitle: {
    fontSize: 15,
    fontWeight: "700",
    color: "#111827",
    marginBottom: 2,
  },
  bundleDesc: {
    fontSize: 12,
    color: "#6B7280",
    marginBottom: 8,
  },
  bundleMetaRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  bundleTimePill: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#F3F4F6",
    borderRadius: 999,
    paddingHorizontal: 8,
    paddingVertical: 3,
  },
  bundleTimeText: {
    fontSize: 11,
    color: "#4B5563",
    marginLeft: 4,
  },
  bundlePrice: {
    fontSize: 16,
    fontWeight: "800",
    color: "#0B63CE",
  },
  bundleCircleBig: {
    width: 70,
    height: 70,
    borderRadius: 35,
    backgroundColor: "#E6F0FF",
    position: "absolute",
  },
  bundleCircleSmall: {
    width: 42,
    height: 42,
    borderRadius: 21,
    backgroundColor: "#C7E0FF",
    position: "absolute",
    top: 16,
    right: 0,
  },
  bundleEmoji: {
    fontSize: 26,
  },
  productRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 8,
  },
  productLeft: {
    flexDirection: "row",
    alignItems: "center",
    flex: 1.4,
  },
  productEmojiCircle: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: "#FFFFFF",
    justifyContent: "center",
    alignItems: "center",
    marginRight: 10,
    borderWidth: 1,
    borderColor: "#E1E5F0",
  },
  productEmoji: {
    fontSize: 24,
  },
  productName: {
    fontSize: 14,
    fontWeight: "600",
    color: "#111827",
  },
  productMetaRow: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 2,
  },
  productInfo: {
    fontSize: 11,
    color: "#6B7280",
    marginRight: 6,
  },
  productBadge: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#FEF3C7",
    borderRadius: 999,
    paddingHorizontal: 6,
    paddingVertical: 2,
  },
  productBadgeText: {
    fontSize: 11,
    color: "#92400E",
    marginLeft: 2,
  },
  productRight: {
    alignItems: "flex-end",
    flex: 0.8,
  },
  productPrice: {
    fontSize: 14,
    fontWeight: "700",
    color: "#0B63CE",
    marginBottom: 4,
  },
  productAddButton: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#0B63CE",
    borderRadius: 999,
    paddingHorizontal: 10,
    paddingVertical: 5,
  },
  productAddText: {
    fontSize: 11,
    color: "#FFFFFF",
    fontWeight: "600",
  },
  productDivider: {
    height: 1,
    backgroundColor: "#E5E7EB",
  },
  footerCard: {
    marginTop: 18,
    marginBottom: 8,
    backgroundColor: "#FFFFFF",
    borderRadius: 18,
    padding: 14,
    borderWidth: 1,
    borderColor: "#E1E5F0",
  },
  footerTitle: {
    fontSize: 14,
    fontWeight: "700",
    color: "#111827",
    marginBottom: 4,
  },
  footerText: {
    fontSize: 12,
    color: "#6B7280",
    marginBottom: 10,
  },
  footerPillsRow: {
    flexDirection: "row",
    flexWrap: "wrap",
  },
  footerPill: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#E6F0FF",
    borderRadius: 999,
    paddingHorizontal: 8,
    paddingVertical: 4,
    marginRight: 6,
    marginBottom: 6,
  },
  footerPillText: {
    fontSize: 11,
    color: "#1C2439",
    marginLeft: 4,
  },
  bottomNav: {
    position: "absolute",
    left: 0,
    right: 0,
    bottom: 0,
    height: 72,
    flexDirection: "row",
    backgroundColor: "#FFFFFF",
    borderTopWidth: 1,
    borderTopColor: "#E1E5F0",
    paddingHorizontal: 12,
    paddingBottom: 10,
    paddingTop: 8,
    justifyContent: "space-between",
  },
  navItem: {
    flex: 1,
    alignItems: "center",
    justifyContent: "flex-start",
  },
  navLabel: {
    fontSize: 11,
    color: "#98A2B3",
    marginTop: 2,
  },
  navLabelActive: {
    color: "#0B63CE",
    fontWeight: "600",
  },
  navIndicator: {
    width: 24,
    height: 3,
    borderRadius: 999,
    backgroundColor: "#0B63CE",
    marginTop: 4,
  },

  














  headerCentered: {
  paddingTop: 7,
  paddingBottom: 12,
  alignItems: "center",
  justifyContent: "center",
},

headerLogo: {
  fontSize: 30,
  fontWeight: "900",
  color: "#0B63CE",
  letterSpacing: 0.5,
},

headerSubRow: {
  flexDirection: "row",
  alignItems: "center",
  marginTop: 4,
},

headerSubText: {
  fontSize: 12,
  color: "#7C8AA3",
  marginLeft: 4,
},

headerAddressButton: {
  flexDirection: "row",
  alignItems: "center",
  backgroundColor: "#E6F0FF",
  borderRadius: 999,
  paddingHorizontal: 14,
  paddingVertical: 6,
  marginTop: 10,
},

headerAddressText: {
  fontSize: 12,
  color: "#1C2439",
  marginHorizontal: 6,
},

headerNotif: {
  marginTop: 10,
  width: 38,
  height: 38,
  borderRadius: 19,
  backgroundColor: "#FFFFFF",
  borderColor: "#E0E4F0",
  borderWidth: 1,
  justifyContent: "center",
  alignItems: "center",
},









appleHeaderPro: {
  width: "100%",
  paddingTop: 25,
  paddingBottom: 20,
  paddingHorizontal: 18,
  alignItems: "center",
  justifyContent: "center",

  backgroundColor: "rgba(255,255,255,0.75)",
  backdropFilter: "blur(20px)",

  borderBottomWidth: 1,
  borderBottomColor: "rgba(200,200,200,0.25)",

  shadowColor: "#000",
  shadowOpacity: 0.08,
  shadowRadius: 22,
  shadowOffset: { width: 0, height: 12 },

  elevation: 8,
},


topTitle: {
  fontSize: 32,
  fontWeight: "900",
  letterSpacing: 0.7,
  color: "#0B63CE",
  textAlign: "center",
},

subRow: {
  flexDirection: "row",
  alignItems: "center",
  justifyContent: "center",
  marginTop: 6,
},

subText: {
  fontSize: 14,
  marginLeft: 6,
  color: "#6B7280",
  fontWeight: "600",
},

addressCard: {
  marginTop: 16,
  backgroundColor: "#EAF2FF",
  paddingVertical: 12,
  paddingHorizontal: 16,
  borderRadius: 16,
  flexDirection: "row",
  alignItems: "center",

  width: "95%", // dolgun görünüm
  shadowColor: "#0B63CE",
  shadowOpacity: 0.1,
  shadowRadius: 12,
  shadowOffset: { width: 0, height: 6 },
},

appleAddressText: {
  fontSize: 15,
  fontWeight: "600",
  color: "#0B63CE",
  marginHorizontal: 8,
  flex: 1,
  textAlign: "center",
},


notifButton: {
  position: "absolute",
  top: 10,
  right: 16,
  width: 42,
  height: 42,
  borderRadius: 21,
  backgroundColor: "#FFFFFF",
  justifyContent: "center",
  alignItems: "center",

  shadowColor: "#000",
  shadowOpacity: 0.1,
  shadowRadius: 10,
  shadowOffset: { width: 0, height: 4 },
},


notifDot: {
  position: "absolute",
  top: 8,
  right: 10,
  width: 10,
  height: 10,
  borderRadius: 5,
  backgroundColor: "#FF6B00",
},

});
