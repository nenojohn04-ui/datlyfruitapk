import React, { useMemo, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  StatusBar,
  TextInput,
  TouchableOpacity,
  FlatList,
  ScrollView,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useRouter } from "expo-router";


const CATEGORIES = [
  { id: "all", name: "Tümü" },
  { id: "fruit", name: "Meyve" },
  { id: "vegetables", name: "Sebze" },
  { id: "dairy", name: "Süt & Kahvaltı" },
  { id: "drinks", name: "İçecek" },
  { id: "snacks", name: "Atıştırmalık" },
  { id: "cleaning", name: "Temizlik" },
];

const SORT_OPTIONS = [
  { id: "recommended", label: "Önerilen" },
  { id: "rating", label: "Puan" },
  { id: "price_low", label: "Fiyat (Artan)" },
  { id: "price_high", label: "Fiyat (Azalan)" },
];

const PRODUCTS = [
  {
    id: "1",
    name: "Fuji Elma 1kg",
    desc: "Aomori ithal, ekstra premium, kalibreli elma.",
    price: 69.9,
    oldPrice: 79.9,
    rating: 4.9,
    reviews: 212,
    label: "En çok satan",
    category: "fruit",
    deliverySlot: "Bugün • 30-45 dk",
    store: "DatlyFruit Express",
    badgeColor: "#ECFEFF",
  },
  {
    id: "2",
    name: "Muz 1kg",
    desc: "Her gün taze, Honduras & Ekvador karışım.",
    price: 54.5,
    oldPrice: 59.9,
    rating: 4.8,
    reviews: 341,
    label: "Fırsat",
    category: "fruit",
    deliverySlot: "Bugün • 25-40 dk",
    store: "DatlyFruit Market",
    badgeColor: "#FEF3C7",
  },
  {
    id: "3",
    name: "Salkım Domates 1kg",
    desc: "Seradan sofraya, aromalı salkım domates.",
    price: 49.9,
    oldPrice: 0,
    rating: 4.7,
    reviews: 128,
    label: "Şef önerisi",
    category: "vegetables",
    deliverySlot: "Bugün • 40-60 dk",
    store: "DatlyFruit Express",
    badgeColor: "#E0F2FE",
  },
  {
    id: "4",
    name: "Taze Süt 1L",
    desc: "Soğuk zincir garantili, günlük pastörize.",
    price: 32.9,
    oldPrice: 36.9,
    rating: 4.9,
    reviews: 521,
    label: "Kahvaltı favorisi",
    category: "dairy",
    deliverySlot: "Bugün • 20-35 dk",
    store: "DatlyFruit Cold",
    badgeColor: "#E0F2FE",
  },
  {
    id: "5",
    name: "Filtre Kahve 250g",
    desc: "3. nesil kavrum, orta kavrulmuş, dengeli asidite.",
    price: 119.9,
    oldPrice: 129.9,
    rating: 4.8,
    reviews: 289,
    label: "Ofis ürünü",
    category: "breakfast",
    deliverySlot: "Bugün • 60-75 dk",
    store: "Datly Pro",
    badgeColor: "#EEF2FF",
  },
  {
    id: "6",
    name: "Gazlı İçecek 1.5L",
    desc: "Aile boyu, buz gibi servis için hazır.",
    price: 29.9,
    oldPrice: 0,
    rating: 4.5,
    reviews: 98,
    label: "Çok al az öde",
    category: "drinks",
    deliverySlot: "Bugün • 30-50 dk",
    store: "DatlyFruit Market",
    badgeColor: "#E0F2FE",
  },
  {
    id: "7",
    name: "Çamaşır Deterjanı 4.5kg",
    desc: "Yoğun formül, 45 yıkamaya kadar.",
    price: 189.9,
    oldPrice: 219.9,
    rating: 4.9,
    reviews: 411,
    label: "Ev favorisi",
    category: "cleaning",
    deliverySlot: "Bugün • 90-120 dk",
    store: "Datly Home Care",
    badgeColor: "#ECFEFF",
  },
  {
    id: "8",
    name: "Patates 2.5kg",
    desc: "Fırın, kızartma ve püre için çok amaçlı.",
    price: 59.9,
    oldPrice: 0,
    rating: 4.6,
    reviews: 154,
    label: "Ekonomik paket",
    category: "vegetables",
    deliverySlot: "Bugün • 45-70 dk",
    store: "DatlyFruit Express",
    badgeColor: "#FEF9C3",
  },
];

const formatPrice = (value: number) => `₺${value.toFixed(2)}`;













type BottomNavProps = {
  activeNav: string;
  setActiveNav: (value: string) => void;
  router: any;
};

const BottomNavBar = ({ activeNav, setActiveNav, router }: BottomNavProps) => {
  const handlePress = (navKey: string, route: string) => {
    // 🔥 Eğer şu anda o sayfadaysan → hiçbir şey yapma, push etme!
    if (activeNav === navKey) return;

    setActiveNav(navKey);
    router.push(route);
  };

  return (
    <View style={styles.bottomNav}>
      <NavItem
        label="Home"
        icon="home-outline"
        active={activeNav === "HOME"}
       onPress={() => handlePress("CATEGORIES", "/")}

      />

      <NavItem
        label="Catalog"
        icon="grid-outline"
        active={activeNav === "CATEGORIES"}
        onPress={() => handlePress("CATEGORIES", "/WalmartScreen")}
      />

      <NavItem
        label="Orders"
        icon="receipt-outline"
        active={activeNav === "ORDERS"}
        onPress={() => handlePress("ORDERS", "/OrdersScreen")}
      />

      <NavItem
        label="Cart"
        icon="cart-outline"
        active={activeNav === "CART"}
        onPress={() => handlePress("CART", "/CartScreen")}
      />

      <NavItem
        label="Profile"
        icon="person-outline"
        active={activeNav === "PROFILE"}
        onPress={() => handlePress("PROFILE", "/ProfileScreen")}
      />
    </View>
  );
};




const NavItem = ({ label, icon, active, onPress }) => (
  <TouchableOpacity style={styles.navItem} onPress={onPress} activeOpacity={0.8}>
    <Ionicons
      name={icon}
      size={22}
      color={active ? "#0B63CE" : "#98A2B3"}
    />

    <Text style={[styles.navLabel, active && styles.navLabelActive]}>
      {label}
    </Text>

    {active && <View style={styles.navIndicator} />}
  </TouchableOpacity>
);











export default function DatlyDeliveryScreen() {

  // ❌ BUNU SİL → const navigation = useNavigation<any>();
  // Çünkü expo-router kullanıyoruz.

  // ✅ BUNU EKLE:
  const router = useRouter();
  const [activeNav, setActiveNav] = useState("HOME");
  const [activeCategory, setActiveCategory] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [sortOption, setSortOption] = useState("recommended");
  const [cart, setCart] = useState<{ [productId: string]: number }>({});


  const cartTotalItems = useMemo(
    () => Object.values(cart).reduce((sum, qty) => sum + qty, 0),
    [cart]
  );

  const cartSubtotal = useMemo(() => {
    return Object.entries(cart).reduce((sum, [productId, qty]) => {
      const p = PRODUCTS.find((x) => x.id === productId);
      if (!p) return sum;
      return sum + p.price * qty;
    }, 0);
  }, [cart]);

  const filteredProducts = useMemo(() => {
    let result = [...PRODUCTS];

    if (activeCategory !== "all") {
      result = result.filter((p) => p.category === activeCategory);
    }

    if (searchQuery.trim().length > 0) {
      const q = searchQuery.toLowerCase();
      result = result.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.desc.toLowerCase().includes(q) ||
          p.store.toLowerCase().includes(q)
      );
    }

    if (sortOption === "rating") {
      result.sort((a, b) => b.rating - a.rating);
    } else if (sortOption === "price_low") {
      result.sort((a, b) => a.price - b.price);
    } else if (sortOption === "price_high") {
      result.sort((a, b) => b.price - a.price);
    } else {
      // "recommended" – hiçbir şey yapma, default sırayı koru
    }

    return result;
  }, [activeCategory, searchQuery, sortOption]);

  const handleAddToCart = (id: string) => {
    setCart((prev) => ({
      ...prev,
      [id]: (prev[id] || 0) + 1,
    }));
  };

  const handleDecrease = (id: string) => {
    setCart((prev) => {
      const current = prev[id] || 0;
      if (current <= 1) {
        const copy = { ...prev };
        delete copy[id];
        return copy;
      }
      return { ...prev, [id]: current - 1 };
    });
  };

  const renderProduct = ({ item }: { item: (typeof PRODUCTS)[number] }) => {
    const qty = cart[item.id] || 0;

    return (
      <TouchableOpacity style={styles.productCard} activeOpacity={0.9}>
        {/* LEFT IMAGE/BOX */}
        <View style={styles.productImageBox}>
          <View style={styles.productImageShadow}>
            <View style={styles.productImagePlaceholder}>
              <Text style={styles.productEmoji}>🛒</Text>
            </View>
          </View>
        </View>

        {/* RIGHT CONTENT */}
        <View style={styles.productContent}>
          <View style={styles.productTopRow}>
            <Text style={styles.productName} numberOfLines={2}>
              {item.name}
            </Text>
            <Text style={styles.storeText} numberOfLines={1}>
              {item.store}
            </Text>
          </View>

          <Text style={styles.productDesc} numberOfLines={2}>
            {item.desc}
          </Text>

          <View style={styles.deliveryRow}>
            <Ionicons name="bicycle-outline" size={14} color="#0B63CE" />
            <Text style={styles.deliveryText}>{item.deliverySlot}</Text>
          </View>

          <View style={styles.priceRow}>
            <Text style={styles.priceText}>{formatPrice(item.price)}</Text>
            {item.oldPrice > 0 && (
              <Text style={styles.oldPriceText}>
                {formatPrice(item.oldPrice)}
              </Text>
            )}
          </View>

          <View style={styles.ratingRow}>
            <Ionicons name="star" size={13} color="#FACC15" />
            <Ionicons name="star" size={13} color="#FACC15" />
            <Ionicons name="star" size={13} color="#FACC15" />
            <Ionicons name="star" size={13} color="#FACC15" />
            <Ionicons name="star-half" size={13} color="#FACC15" />
            <Text style={styles.ratingText}>
              {item.rating.toFixed(1)} • {item.reviews}+ değerlendirme
            </Text>
          </View>

          <View style={styles.bottomRow}>
            <View
              style={[
                styles.labelPill,
                { backgroundColor: item.badgeColor || "#ECFEFF" },
              ]}
            >
              <Text style={styles.labelPillText}>{item.label}</Text>
            </View>

            {qty === 0 ? (
              <TouchableOpacity
                style={styles.addButton}
                activeOpacity={0.9}
                onPress={() => handleAddToCart(item.id)}
              >
                <Ionicons name="add" size={16} color="#FFFFFF" />
                <Text style={styles.addButtonText}>Add</Text>
              </TouchableOpacity>
            ) : (
              <View style={styles.qtyContainer}>
                <TouchableOpacity
                  style={styles.qtyButton}
                  onPress={() => handleDecrease(item.id)}
                >
                  <Ionicons name="remove" size={16} color="#0B63CE" />
                </TouchableOpacity>
                <Text style={styles.qtyText}>{qty}</Text>
                <TouchableOpacity
                  style={styles.qtyButton}
                  onPress={() => handleAddToCart(item.id)}
                >
                  <Ionicons name="add" size={16} color="#0B63CE" />
                </TouchableOpacity>
              </View>
            )}
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  const ListHeader = () => (
    <View>
      {/* HEADER */}
      <View style={styles.header}>
        <StatusBar barStyle="light-content" backgroundColor="#0B63CE" />
       <View style={styles.headerTopRow}>
  
  {/* SOL TARAF (GERİ TUŞU + ADRES) */}
  <View style={styles.headerLeft}>
<TouchableOpacity onPress={() => router.push("/")}>
  <Ionicons name="arrow-back" size={22} color="#FFFFFF" />
</TouchableOpacity>



    <View style={{ marginLeft: 8 }}>
      <Text style={styles.headerSubtitle}>Teslimat adresi</Text>
      <View style={styles.headerTitleRow}>
        <Text style={styles.headerTitle} numberOfLines={1}>
          34710 - İstanbul, Kadıköy
        </Text>
        <Ionicons
          name="chevron-down"
          size={16}
          color="#BFDBFE"
          style={{ marginLeft: 4 }}
        />
      </View>
    </View>
  </View>

  {/* SAĞ TARAF (Bildirim + Sepet) */}
  <View style={styles.headerRightIcons}>
    <TouchableOpacity style={styles.headerIconCircle}>
      <Ionicons name="notifications-outline" size={20} color="#FFFFFF" />
    </TouchableOpacity>

    <TouchableOpacity style={[styles.headerIconCircle, { marginLeft: 8 }]}>
      <Ionicons name="cart-outline" size={20} color="#FFFFFF" />
      {cartTotalItems > 0 && (
        <View style={styles.cartBadge}>
          <Text style={styles.cartBadgeText}>{cartTotalItems}</Text>
        </View>
      )}
    </TouchableOpacity>
  </View>

</View>

        {/* SEARCH / FILTER */}
        <View style={styles.searchRow}>
          <View style={styles.searchBox}>
            <Ionicons name="search-outline" size={18} color="#6B7280" />
            <TextInput
              placeholder="Ürün, kategori veya market ara"
              placeholderTextColor="#9CA3AF"
              style={styles.searchInput}
              value={searchQuery}
              onChangeText={setSearchQuery}
            />
          </View>
          <TouchableOpacity style={styles.filterIcon}>
            <Ionicons name="options-outline" size={20} color="#0B63CE" />
          </TouchableOpacity>
        </View>
      </View>

      {/* TIMER / INFO BAR */}
      <View style={styles.timerBar}>
        <Ionicons name="time-outline" size={18} color="#0B63CE" />
        <View style={{ marginLeft: 8, flex: 1 }}>
          <Text style={styles.timerTitle}>16:30 öncesi sipariş ver</Text>
          <Text style={styles.timerText}>Bugün içinde teslimat • 30-90 dk</Text>
        </View>
        <View style={styles.timerChip}>
          <Text style={styles.timerChipText}>Detaylar</Text>
        </View>
      </View>

      {/* PROMO STRIP */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={styles.promoScroll}
        contentContainerStyle={{ paddingHorizontal: 12 }}
      >
        <View style={styles.promoCardPrimary}>
          <View style={{ flex: 1 }}>
            <Text style={styles.promoTitle}>₺250 üzeri kargo bedava</Text>
            <Text style={styles.promoSubtitle}>Sadece DatlyFruit Express'te</Text>
          </View>
          <Ionicons name="card-outline" size={32} color="#EFF6FF" />
        </View>

        <View style={styles.promoCardSecondary}>
          <Ionicons name="pricetag-outline" size={20} color="#0B63CE" />
          <Text style={styles.promoSecondaryText}>
            Seçili meyvelerde 2. ürün %50
          </Text>
        </View>

        <View style={styles.promoCardSecondary}>
          <Ionicons name="shield-checkmark-outline" size={20} color="#0B63CE" />
          <Text style={styles.promoSecondaryText}>
            Banka kartı / kredi kartı / kapıda ödeme
          </Text>
        </View>
      </ScrollView>

      {/* CATEGORY BAR */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={styles.categoryScroll}
        contentContainerStyle={{ paddingHorizontal: 12 }}
      >
        {CATEGORIES.map((cat) => {
          const isActive = activeCategory === cat.id;
          return (
            <TouchableOpacity
              key={cat.id}
              style={[
                styles.categoryChip,
                isActive && styles.categoryChipActive,
              ]}
              activeOpacity={0.8}
              onPress={() => setActiveCategory(cat.id)}
            >
              <Text
                style={[
                  styles.categoryChipText,
                  isActive && styles.categoryChipTextActive,
                ]}
              >
                {cat.name}
              </Text>
            </TouchableOpacity>
          );
        })}
      </ScrollView>

      {/* SORT OPTIONS */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={styles.sortScroll}
        contentContainerStyle={{ paddingHorizontal: 12 }}
      >
        {SORT_OPTIONS.map((opt) => {
          const isActive = sortOption === opt.id;
          return (
            <TouchableOpacity
              key={opt.id}
              style={[
                styles.sortChip,
                isActive && styles.sortChipActive,
              ]}
              onPress={() => setSortOption(opt.id)}
            >
              <Text
                style={[
                  styles.sortChipText,
                  isActive && styles.sortChipTextActive,
                ]}
              >
                {opt.label}
              </Text>
            </TouchableOpacity>
          );
        })}
      </ScrollView>

      {/* LIST HEADER TEXT */}
      <View style={styles.listHeaderRow}>
        <View>
          <Text style={styles.listTitle}>Sana özel öneriler</Text>
          <Text style={styles.listSubtitle}>
            Sepet alışkanlıklarına göre listelendi
          </Text>
        </View>
        <Text style={styles.listCount}>{filteredProducts.length} ürün</Text>
      </View>
    </View>
  );

return (
  <View style={styles.root}>
    
    {/* ANA LİSTE */}
    <FlatList
      data={filteredProducts}
      keyExtractor={(item) => item.id}
      renderItem={renderProduct}
      ListHeaderComponent={ListHeader}
      showsVerticalScrollIndicator={false}
      contentContainerStyle={{
        paddingBottom: cartTotalItems > 0 ? 160 : 100, // 🔥 Alt menü + cart için boşluk
      }}
    />

    {/* SEPET BAR (CART SUMMARY) */}
    {cartTotalItems > 0 && (
      <View style={styles.cartBar}>
        <View style={styles.cartBarLeft}>
          <Text style={styles.cartBarTitle}>
            {cartTotalItems} ürün • {formatPrice(cartSubtotal)}
          </Text>
          <Text style={styles.cartBarSubtitle}>
            Tahmini teslimat: 30-90 dk içinde
          </Text>
        </View>

        <TouchableOpacity style={styles.cartBarButton} activeOpacity={0.9}>
          <Text style={styles.cartBarButtonText}>Devam et</Text>
          <Ionicons name="arrow-forward" size={18} color="#FFFFFF" />
        </TouchableOpacity>
      </View>
    )}

    {/* ALT MENÜ (HER ZAMAN SABİT) */}
    <BottomNavBar
      activeNav={activeNav}
      setActiveNav={setActiveNav}
      router={router}
    />

  </View>
);


}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: "#F3F4F6",
  },

  /* HEADER */
  header: {
    backgroundColor: "#0B63CE",
    paddingTop: 40,
    paddingBottom: 14,
    paddingHorizontal: 16,
  },
  headerTopRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  headerLeft: {
    flexDirection: "row",
    alignItems: "center",
    flex: 1,
  },
  headerSubtitle: {
    fontSize: 11,
    color: "#DBEAFE",
  },
  headerTitleRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  headerTitle: {
    fontSize: 15,
    fontWeight: "800",
    color: "#FFFFFF",
    maxWidth: 190,
  },
  headerRightIcons: {
    flexDirection: "row",
    alignItems: "center",
  },
  headerIconCircle: {
    width: 34,
    height: 34,
    borderRadius: 17,
    borderWidth: 1,
    borderColor: "#DBEAFE",
    justifyContent: "center",
    alignItems: "center",
    position: "relative",
  },
  cartBadge: {
    position: "absolute",
    right: -4,
    top: -4,
    minWidth: 16,
    height: 16,
    borderRadius: 8,
    backgroundColor: "#F97316",
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: 2,
  },
  cartBadgeText: {
    fontSize: 10,
    color: "#FFFFFF",
    fontWeight: "800",
  },

  searchRow: {
    marginTop: 12,
    flexDirection: "row",
    alignItems: "center",
  },
  searchBox: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#FFFFFF",
    borderRadius: 999,
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
  searchInput: {
    flex: 1,
    marginLeft: 6,
    fontSize: 13,
    color: "#111827",
  },
  filterIcon: {
    marginLeft: 8,
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: "#FFFFFF",
    justifyContent: "center",
    alignItems: "center",
  },

  /* TIMER BAR */
  timerBar: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#E0F2FE",
    marginHorizontal: 12,
    marginTop: 10,
    borderRadius: 12,
    paddingHorizontal: 10,
    paddingVertical: 8,
  },
  timerTitle: {
    fontSize: 13,
    fontWeight: "700",
    color: "#0F172A",
  },
  timerText: {
    fontSize: 11,
    color: "#4B5563",
  },
  timerChip: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 999,
    backgroundColor: "#0B63CE",
  },
  timerChipText: {
    fontSize: 11,
    fontWeight: "700",
    color: "#FFFFFF",
  },

  /* PROMO */
  promoScroll: {
    marginTop: 10,
    marginBottom: 4,
  },
  promoCardPrimary: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#1D4ED8",
    paddingVertical: 12,
    paddingHorizontal: 14,
    borderRadius: 16,
    marginRight: 10,
    minWidth: 260,
  },
  promoTitle: {
    fontSize: 15,
    color: "#EFF6FF",
    fontWeight: "800",
  },
  promoSubtitle: {
    fontSize: 11,
    color: "#BFDBFE",
    marginTop: 2,
  },
  promoCardSecondary: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#EFF6FF",
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 999,
    marginRight: 8,
  },
  promoSecondaryText: {
    fontSize: 11,
    color: "#0F172A",
    marginLeft: 4,
  },

  /* CATEGORY BAR */
  categoryScroll: {
    marginTop: 8,
    marginBottom: 4,
  },
  categoryChip: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 999,
    backgroundColor: "#FFFFFF",
    marginRight: 8,
    borderWidth: 1,
    borderColor: "#E5E7EB",
  },
  categoryChipActive: {
    backgroundColor: "#0B63CE",
    borderColor: "#0B63CE",
  },
  categoryChipText: {
    fontSize: 13,
    color: "#111827",
    fontWeight: "500",
  },
  categoryChipTextActive: {
    color: "#FFFFFF",
    fontWeight: "700",
  },

  /* SORT BAR */
  sortScroll: {
    marginTop: 4,
    marginBottom: 6,
  },
  sortChip: {
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    backgroundColor: "#E5E7EB",
    marginRight: 8,
  },
  sortChipActive: {
    backgroundColor: "#0B63CE",
  },
  sortChipText: {
    fontSize: 11,
    color: "#111827",
  },
  sortChipTextActive: {
    color: "#FFFFFF",
    fontWeight: "600",
  },

  /* LIST HEADER */
  listHeaderRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-end",
    marginHorizontal: 16,
    marginBottom: 6,
    marginTop: 4,
  },
  listTitle: {
    fontSize: 16,
    fontWeight: "800",
    color: "#111827",
  },
  listSubtitle: {
    fontSize: 11,
    color: "#6B7280",
    marginTop: 2,
  },
  listCount: {
    fontSize: 12,
    color: "#6B7280",
  },

  /* PRODUCT CARD */
  productCard: {
    flexDirection: "row",
    marginHorizontal: 12,
    marginTop: 8,
    backgroundColor: "#FFFFFF",
    borderRadius: 16,
    padding: 12,
    borderWidth: 1,
    borderColor: "#E5E7EB",
    shadowColor: "#000",
    shadowOpacity: 0.06,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 3 },
  },
  productImageBox: {
    marginRight: 12,
  },
  productImageShadow: {
    width: 90,
    height: 90,
    borderRadius: 18,
    backgroundColor: "#F3F4F6",
    justifyContent: "center",
    alignItems: "center",
  },
  productImagePlaceholder: {
    width: "85%",
    height: "85%",
    borderRadius: 16,
    backgroundColor: "#DBEAFE",
    justifyContent: "center",
    alignItems: "center",
  },
  productEmoji: {
    fontSize: 30,
  },

  productContent: {
    flex: 1,
  },
  productTopRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
  },
  productName: {
    fontSize: 15,
    fontWeight: "700",
    color: "#111827",
    flex: 1,
    marginRight: 8,
  },
  storeText: {
    fontSize: 10,
    color: "#1D4ED8",
    fontWeight: "600",
  },
  productDesc: {
    fontSize: 12,
    color: "#6B7280",
    marginTop: 2,
  },

  deliveryRow: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 4,
  },
  deliveryText: {
    fontSize: 11,
    color: "#0B63CE",
    marginLeft: 4,
  },

  priceRow: {
    flexDirection: "row",
    alignItems: "baseline",
    marginTop: 6,
  },
  priceText: {
    fontSize: 16,
    fontWeight: "800",
    color: "#0B63CE",
  },
  oldPriceText: {
    fontSize: 12,
    color: "#9CA3AF",
    textDecorationLine: "line-through",
    marginLeft: 6,
  },

  ratingRow: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 4,
  },
  ratingText: {
    fontSize: 11,
    color: "#6B7280",
    marginLeft: 6,
  },

  bottomRow: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 8,
    justifyContent: "space-between",
  },
  labelPill: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 999,
  },
  labelPillText: {
    fontSize: 11,
    color: "#0E7490",
    fontWeight: "600",
  },

  addButton: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 999,
    backgroundColor: "#0B63CE",
  },
  addButtonText: {
    fontSize: 13,
    color: "#FFFFFF",
    fontWeight: "700",
    marginLeft: 4,
  },

  qtyContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#EFF6FF",
    borderRadius: 999,
    paddingHorizontal: 4,
    paddingVertical: 4,
  },
  qtyButton: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: "#FFFFFF",
    justifyContent: "center",
    alignItems: "center",
  },
  qtyText: {
    fontSize: 13,
    fontWeight: "700",
    color: "#0B63CE",
    marginHorizontal: 8,
  },

  /* CART BAR */
  cartBar: {
    position: "absolute",
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: 12,
    paddingVertical: 10,
    backgroundColor: "#0F172A",
    flexDirection: "row",
    alignItems: "center",
  },
  cartBarLeft: {
    flex: 1,
  },
  cartBarTitle: {
    fontSize: 14,
    color: "#FFFFFF",
    fontWeight: "700",
  },
  cartBarSubtitle: {
    fontSize: 11,
    color: "#E5E7EB",
    marginTop: 2,
  },
  cartBarButton: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#2563EB",
    borderRadius: 999,
    paddingHorizontal: 16,
    paddingVertical: 10,
    marginLeft: 12,
  },
  cartBarButtonText: {
    fontSize: 13,
    color: "#FFFFFF",
    fontWeight: "700",
    marginRight: 4,
  },















  /* ---------------------- ALT MENÜ ---------------------- */
bottomNav: {
  position: "absolute",
  left: 0,
  right: 0,
  bottom: 0,
  height: 72,
  flexDirection: "row",
  backgroundColor: "#FFFFFF",
  borderTopWidth: 1,
  borderTopColor: "#E1E5F0",
  paddingHorizontal: 12,
  paddingTop: 8,
  paddingBottom: 10,
  justifyContent: "space-between",
},

navItem: {
  flex: 1,
  alignItems: "center",
  justifyContent: "flex-start",
  position: "relative",
},

navLabel: {
  fontSize: 11,
  color: "#98A2B3",
  marginTop: 2,
},

navLabelActive: {
  color: "#0B63CE",
  fontWeight: "600",
},

navIndicator: {
  width: 22,
  height: 3,
  borderRadius: 999,
  backgroundColor: "#0B63CE",
  marginTop: 4,
},

});
