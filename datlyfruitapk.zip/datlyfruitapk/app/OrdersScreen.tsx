// OrdersScreen.tsx
import React, {
  useMemo,
  useState,
  useRef,
  useEffect,
  FC,
} from "react";
import {
  View,
  Text,
  StyleSheet,
  StatusBar,
  TouchableOpacity,
  ScrollView,
  FlatList,
  Modal,
  Animated,
  Pressable,
  SafeAreaView,
  Easing,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useNavigation } from "@react-navigation/native";
// =======================================================
// TYPES
// =======================================================

type LogicalStatus = "active" | "delivered" | "cancelled";

type OrderItem = {
  id: string;
  name: string;
  category: string;
  quantityKg: number;
  price: number;
};

type Order = {
  id: string;
  date: string;
  total: number;
  durum: string;
  logicalStatus: LogicalStatus;
  items: OrderItem[];
};

// =======================================================
// DUMMY DATA (Backend formatına birebir yakın)
// =======================================================

const ORDERS: Order[] = [
  {
    id: "10234",
    date: "2025-12-09 19:24",
    total: 378.4,
    durum: "Kuryä berildi",
    logicalStatus: "active",
    items: [
      { id: "1", name: "Fuji alma 1kg", category: "Miwe", quantityKg: 2, price: 32 },
      { id: "2", name: "Banana 1kg", category: "Miwe", quantityKg: 1, price: 25 },
      { id: "3", name: "Pomidor 1kg", category: "Sebze", quantityKg: 1.5, price: 18 },
    ],
  },
  {
    id: "10235",
    date: "2025-12-08 11:04",
    total: 142.5,
    durum: "Ýolda",
    logicalStatus: "active",
    items: [
      { id: "4", name: "Hytaý üzümi 1kg", category: "Miwe", quantityKg: 3, price: 27 },
      { id: "5", name: "Hytaý armudy 1kg", category: "Miwe", quantityKg: 1, price: 24.5 },
    ],
  },
  {
    id: "10236",
    date: "2025-12-05 20:35",
    total: 96.0,
    durum: "Teslim edildi",
    logicalStatus: "delivered",
    items: [
      { id: "6", name: "Salat paketi", category: "Sebze", quantityKg: 1, price: 48 },
      { id: "7", name: "Gök önümler mix", category: "Sebze", quantityKg: 1, price: 48 },
    ],
  },
  {
    id: "10237",
    date: "2025-12-01 10:18",
    total: 58.0,
    durum: "Sargyt ýatyryldy",
    logicalStatus: "cancelled",
    items: [
      { id: "8", name: "Mandarin 1kg", category: "Miwe", quantityKg: 2, price: 29 },
    ],
  },
];

// =======================================================
// STATUS UI ENGINE (renk – badge – progress)
// =======================================================

const getStatusUI = (logical: LogicalStatus, durum: string) => {
  const d = durum.toLowerCase();

  // 1) TESLİM EDİLDİ → %100
  if (logical === "delivered")
    return {
      badgeBg: "#E5F6EE",
      badgeBorder: "#22C55E",
      badgeText: "#166534",
      progress: 1,            // ✔ TAM DOLU
      progressColor: "#22C55E",
      label: durum,
    };

  // 2) İPTAL → %0
  if (logical === "cancelled")
    return {
      badgeBg: "#FEE2E2",
      badgeBorder: "#F87171",
      badgeText: "#B91C1C",
      progress: 0,            // ✔ BOŞ
      progressColor: "#F87171",
      label: durum,
    };

  // 3) YOLDA → %50
  if (d.includes("ýolda") || d.includes("yolda")) {
    return {
      badgeBg: "#E0F2FF",
      badgeBorder: "#38BDF8",
      badgeText: "#0369A1",
      progress: 0.5,          // ✔ %50
      progressColor: "#38BDF8",
      label: durum,
    };
  }

  // 4) Kuryä berildi → %30
  if (d.includes("kury")) {
    return {
      badgeBg: "#E5E4FF",
      badgeBorder: "#A855F7",
      badgeText: "#4338CA",
      progress: 0.3,          // ✔ %30
      progressColor: "#A855F7",
      label: durum,
    };
  }

  // 5) İşjeň / Hazırlanýar → %15
  return {
    badgeBg: "#FFF7E6",
    badgeBorder: "#FBBF24",
    badgeText: "#B45309",
    progress: 0.15,           // ✔ %15
    progressColor: "#FBBF24",
    label: durum,
  };
};



// =======================================================
// FILTER CHIP COMPONENT
// =======================================================

const FilterChip: FC<{
  label: string;
  active: boolean;
  onPress: () => void;
}> = ({ label, active, onPress }) => (
  <TouchableOpacity
    onPress={onPress}
    style={[styles.filterChip, active && styles.filterChipActive]}
  >
    <Text
      style={[styles.filterChipText, active && styles.filterChipTextActive]}
    >
      {label}
    </Text>
  </TouchableOpacity>
);

// =======================================================
// MAIN COMPONENT
// =======================================================

const OrdersScreen: FC = () => {
  const navigation = useNavigation();  // ✔ EN ÜSTE

  const [filter, setFilter] = useState<
    "all" | "active" | "delivered" | "cancelled"
  >("all");

  const [selected, setSelected] = useState<Order | null>(null);


  // KPI
  const kpi = useMemo(() => {
    let act = 0,
      del = 0,
      can = 0;
    ORDERS.forEach((o) => {
      if (o.logicalStatus === "active") act++;
      else if (o.logicalStatus === "delivered") del++;
      else if (o.logicalStatus === "cancelled") can++;
    });
    return { act, del, can };
  }, []);

  const filtered = useMemo(() => {
    if (filter === "all") return ORDERS;
    return ORDERS.filter((o) => o.logicalStatus === filter);
  }, [filter]);

  // Bottom sheet animation
  const sheetY = useRef(new Animated.Value(300)).current;
  const backdrop = useRef(new Animated.Value(0)).current;

  const openSheet = () => {
    Animated.parallel([
      Animated.timing(backdrop, {
        toValue: 1,
        duration: 180,
        useNativeDriver: true,
      }),
      Animated.timing(sheetY, {
        toValue: 0,
        duration: 260,
        easing: Easing.out(Easing.quad),
        useNativeDriver: true,
      }),
    ]).start();
  };

  const closeSheet = () => {
    Animated.parallel([
      Animated.timing(backdrop, {
        toValue: 0,
        duration: 140,
        useNativeDriver: true,
      }),
      Animated.timing(sheetY, {
        toValue: 300,
        duration: 220,
        easing: Easing.in(Easing.quad),
        useNativeDriver: true,
      }),
    ]).start(() => setSelected(null));
  };

  const handleSelect = (o: Order) => {
    setSelected(o);
    openSheet();
  };

  // =====================================================
  // ORDER CARD COMPONENT (INLINE)
  // =====================================================
  const renderCard = ({ item }: { item: Order }) => {
    const ui = getStatusUI(item.logicalStatus, item.durum);

    const mini =
      item.items.length === 0
        ? "Önüm ýok"
        : `${item.items[0].name} • ${item.items[0].quantityKg} kg${
            item.items.length > 1
              ? ` (+${item.items.length - 1} sany başga)`
              : ""
          }`;

   const progressWidth = ui.progress * 100; // sayı

    return (
      <Pressable onPress={() => handleSelect(item)} style={styles.timelineItem}>
        <View style={styles.card}>
          {/* HEAD */}
          <View style={styles.cardHead}>
            <Text style={styles.cardId}>Sargyt #{item.id}</Text>
            <View style={styles.dateRow}>
              <Ionicons name="calendar-outline" size={14} color="#6B7280" />
              <Text style={styles.dateText}>{item.date}</Text>
            </View>
          </View>

          {/* BADGE */}
          <View
            style={[
              styles.badge,
              {
                backgroundColor: ui.badgeBg,
                borderColor: ui.badgeBorder,
              },
            ]}
          >
            <View
              style={[
                styles.dot,
                { backgroundColor: ui.badgeText },
              ]}
            />
            <Text style={[styles.badgeText, { color: ui.badgeText }]}>
              {ui.label}
            </Text>
          </View>

          {/* MAIN ROW */}
          <View style={styles.mainRow}>
            <Text style={styles.total}>{item.total.toFixed(2)} TMT</Text>
            <Text style={styles.mini}>{mini}</Text>
          </View>

          {/* PRODUCT MINI LIST */}
          <View style={styles.productWrap}>
            {item.items.slice(0, 2).map((p) => (
              <Text key={p.id} style={styles.productLine}>
                • {p.name} — {p.category} — {p.quantityKg} kg × {p.price} TMT
              </Text>
            ))}
          </View>

          {/* PROGRESS BAR */}
          {/* PROGRESS BAR */} 
<View style={styles.progressBg}>
<Animated.View
  style={[
    styles.progressFill,
    {
      width: `${ui.progress * 100}%`,   // ✔ yüzde tipinde tam doğru
      backgroundColor: ui.progressColor,
    },
  ]}
/>

</View>


        </View>
      </Pressable>
    );
  };

  // =====================================================
  // RENDER
  // =====================================================

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="dark-content" backgroundColor="#F9FBFF" />

      <View style={styles.container}>
        {/* TOPBAR */}
        <View style={styles.topbar}>
          <View style={styles.topbarLeft}>
           <TouchableOpacity
  style={styles.backBtn}
  onPress={() => navigation.goBack()}   // ✔ Geri gider
>
  <Ionicons name="chevron-back" size={20} color="#00245C" />
</TouchableOpacity>

            <View>
              <Text style={styles.topSmall}>DatlyFruit • Sargyt taryhy</Text>
              <Text style={styles.topTitle}>Sargytlarym</Text>
            </View>
          </View>

          <View style={styles.pill}>
            <Ionicons name="receipt-outline" size={14} color="#0055CC" />
            <Text style={styles.pillText}>{ORDERS.length} sargyt</Text>
          </View>
        </View>

        {/* KPI */}
        <View style={styles.kpiRow}>
          <KPI label="Işjeň" value={kpi.act} color="#16a34a" />
          <KPI label="Teslim edilen" value={kpi.del} color="#2563eb" />
          <KPI label="Ýatyrylan" value={kpi.can} color="#b91c1c" />
        </View>

        {/* FILTERS */}
  <View style={{ paddingLeft: 16, marginBottom: 6 }}>
  <ScrollView
    horizontal
    showsHorizontalScrollIndicator={false}
    contentContainerStyle={{ paddingRight: 16 }}
  >
    <FilterChip
      label="Hemmesi"
      active={filter === "all"}
      onPress={() => setFilter("all")}
    />
    <FilterChip
      label="Işjeň"
      active={filter === "active"}
      onPress={() => setFilter("active")}
    />
    <FilterChip
      label="Teslim edilen"
      active={filter === "delivered"}
      onPress={() => setFilter("delivered")}
    />
    <FilterChip
      label="Ýatyrylan"
      active={filter === "cancelled"}
      onPress={() => setFilter("cancelled")}
    />
  </ScrollView>
</View>


        {/* ORDER LIST */}
        <FlatList
          data={filtered}
          renderItem={renderCard}
          keyExtractor={(i) => i.id}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingHorizontal: 14, paddingBottom: 100 }}
        />

        {/* BOTTOM SHEET */}
        {selected && (
          <Animated.View
            style={[
              styles.backdrop,
              { opacity: backdrop },
            ]}
          >
            <Pressable style={{ flex: 1 }} onPress={closeSheet} />
            <Animated.View
              style={[
                styles.sheet,
                {
                  transform: [
                    {
                      translateY: sheetY,
                    },
                  ],
                },
              ]}
            >
              <View style={styles.sheetHandle} />

              <View style={styles.sheetHead}>
                <View>
                  <Text style={styles.sheetTitle}>Sargyt maglumatlary</Text>
                  <Text style={styles.sheetMeta}>
                    #{selected.id} • {selected.date}
                  </Text>
                </View>
              </View>

              <ScrollView style={styles.sheetItems}>
                {selected.items.map((p) => {
                  const lt = p.price * p.quantityKg;
                  return (
                    <View key={p.id} style={styles.sheetItem}>
                      <Text style={styles.sheetItemTitle}>{p.name}</Text>
                      <Text style={styles.sheetItemSub}>
                        {p.category} • {p.quantityKg} kg × {p.price} TMT
                      </Text>
                      <Text style={styles.sheetItemTotal}>
                        Jemi: {lt.toFixed(2)} TMT
                      </Text>
                    </View>
                  );
                })}
              </ScrollView>

              <View style={styles.sheetFooter}>
                <Text style={styles.totalLabel}>Jemi töleg</Text>
                <Text style={styles.totalValue}>
                  {selected.total.toFixed(2)} TMT
                </Text>

                <TouchableOpacity onPress={closeSheet} style={styles.closeBtn}>
                  <Text style={styles.closeText}>Ýap</Text>
                </TouchableOpacity>
              </View>
            </Animated.View>
          </Animated.View>
        )}
      </View>
    </SafeAreaView>
  );
};

// =======================================================
// KPI COMPONENT
// =======================================================

const KPI: FC<{ label: string; value: number; color: string }> = ({
  label,
  value,
  color,
}) => (
  <View style={styles.kpiChip}>
    <View style={[styles.kpiDot, { backgroundColor: color }]} />
    <Text style={styles.kpiText}>
      {label}: {value}
    </Text>
  </View>
);

// =======================================================
// STYLES — PREMIUM DESIGN
// =======================================================

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: "#F3F6FB",
  },
  container: {
    flex: 1,
  },

  // TOPBAR
  topbar: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: "#FFFFFF",
    borderBottomWidth: 1,
    borderBottomColor: "#E0E7F3",
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  topbarLeft: {
    flexDirection: "row",
    alignItems: "center",
  },
  backBtn: {
    width: 34,
    height: 34,
    borderRadius: 999,
    backgroundColor: "#FFFFFF",
    borderWidth: 1,
    borderColor: "#D0D7E6",
    justifyContent: "center",
    alignItems: "center",
    marginRight: 10,
    elevation: 3,
  },
  topSmall: {
    fontSize: 11,
    color: "#6B7280",
  },
  topTitle: {
    fontSize: 18,
    fontWeight: "800",
    color: "#00245C",
  },

  pill: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 10,
    paddingVertical: 5,
    backgroundColor: "#FFFFFF",
    borderWidth: 1,
    borderColor: "#D0D7E6",
    borderRadius: 999,
    elevation: 2,
  },
  pillText: {
    marginLeft: 6,
    fontSize: 11,
    color: "#556987",
  },

  // KPI
  kpiRow: {
    paddingHorizontal: 16,
    paddingVertical: 6,
    flexDirection: "row",
  },
  kpiChip: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#FFFFFF",
    borderRadius: 999,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderWidth: 1,
    borderColor: "#E0E7F3",
    marginRight: 6,
  },
  kpiDot: {
    width: 7,
    height: 7,
    borderRadius: 999,
    marginRight: 4,
  },
  kpiText: {
    fontSize: 11,
    color: "#556987",
  },

  // FILTER CHIP
  filterChip: {
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 999,
    backgroundColor: "#FFFFFF",
    borderWidth: 1,
    borderColor: "#D0D7E6",
    marginRight: 8,
  },
  filterChipActive: {
    backgroundColor: "#E0ECFF",
    borderColor: "#0055CC",
    elevation: 2,
  },
  filterChipText: {
    fontSize: 11,
    color: "#6B7280",
  },
  filterChipTextActive: {
    color: "#00245C",
    fontWeight: "700",
  },

  // ORDER CARD
  timelineItem: {
    marginBottom: 12,
  },
  card: {
    backgroundColor: "#FFFFFF",
    borderRadius: 14,
    padding: 14,
    borderWidth: 1,
    borderColor: "#DFE7F3",
    elevation: 2,
  },
  cardHead: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  cardId: {
    fontSize: 14,
    fontWeight: "600",
    color: "#00245C",
  },
  dateRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  dateText: {
    marginLeft: 4,
    fontSize: 11,
    color: "#6B7280",
  },

  badge: {
    marginTop: 6,
    marginBottom: 6,
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 999,
    borderWidth: 1,
  },
  badgeText: {
    fontSize: 11,
    fontWeight: "500",
  },
  dot: {
    width: 7,
    height: 7,
    borderRadius: 999,
    marginRight: 6,
  },

  mainRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 6,
  },
  total: {
    fontSize: 18,
    fontWeight: "900",
    color: "#00245C",
  },
  mini: {
    fontSize: 11,
    color: "#6B7280",
    maxWidth: "60%",
    textAlign: "right",
  },

  productWrap: {
    marginBottom: 6,
  },
  productLine: {
    fontSize: 11,
    color: "#4B5563",
  },

  progressBg: {
    backgroundColor: "#E2E8F0",
    height: 6,
    borderRadius: 999,
    overflow: "hidden",
  },
  progressFill: {
    height: 6,
    backgroundColor: "#3B82F6",
    borderRadius: 999,
  },

  // BOTTOM SHEET
  backdrop: {
    position: "absolute",
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    backgroundColor: "rgba(0,0,0,0.45)",
    justifyContent: "flex-end",
  },
  sheet: {
    width: "100%",
    backgroundColor: "#FFFFFF",
    borderTopLeftRadius: 22,
    borderTopRightRadius: 22,
    padding: 20,
  },
  sheetHandle: {
    width: 50,
    height: 4,
    backgroundColor: "#D1D5DB",
    borderRadius: 999,
    alignSelf: "center",
    marginBottom: 10,
  },
  sheetHead: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 6,
  },
  sheetTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: "#00245C",
  },
  sheetMeta: {
    fontSize: 11,
    color: "#6B7280",
  },

  sheetItems: {
    maxHeight: 260,
    marginTop: 12,
  },
  sheetItem: {
    borderBottomWidth: 1,
    borderBottomColor: "#EEF0F2",
    paddingVertical: 10,
  },
  sheetItemTitle: {
    fontSize: 13,
    fontWeight: "600",
  },
  sheetItemSub: {
    fontSize: 11,
    color: "#6B7280",
    marginTop: 2,
  },
  sheetItemTotal: {
    fontSize: 11,
    marginTop: 2,
  },

  sheetFooter: {
    marginTop: 16,
    flexDirection: "row",
    alignItems: "center",
  },
  totalLabel: {
    fontSize: 11,
    color: "#6B7280",
  },
  totalValue: {
    fontSize: 17,
    fontWeight: "800",
    color: "#00245C",
    flex: 1,
    marginLeft: 6,
  },
  closeBtn: {
    backgroundColor: "#0055CC",
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 999,
  },
  closeText: {
    color: "#FFFFFF",
    fontSize: 12,
    fontWeight: "700",
  },
});

export default OrdersScreen;
