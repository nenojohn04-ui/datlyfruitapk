import React, { useMemo, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  StatusBar,
  TouchableOpacity,
  FlatList,
  Modal,
  TextInput,
  KeyboardAvoidingView,
  Platform,
  Alert,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";

type CartItem = {
  id: string;
  name: string;
  detail: string;
  unitPrice: number;
  qty: number;
};

const INITIAL_CART: CartItem[] = [
  {
    id: "1",
    name: "Fuji Elma 1kg",
    detail: "Premium meyve • Soğuk zincir",
    unitPrice: 69.9,
    qty: 2,
  },
  {
    id: "2",
    name: "Muz 1kg",
    detail: "Her gün taze",
    unitPrice: 54.5,
    qty: 1,
  },
];

const DELIVERY_FEE = 5;

type CartScreenProps = {
  onBack?: () => void;
};

export default function CartScreen({ onBack }: CartScreenProps) {
  const [cart, setCart] = useState<CartItem[]>(INITIAL_CART);
  const [sheetVisible, setSheetVisible] = useState(false);

  const [address, setAddress] = useState("İstanbul, Kadıköy");
  const [cardNumber, setCardNumber] = useState("");
  const [expiry, setExpiry] = useState("");
  const [cvc, setCvc] = useState("");
  const [loading, setLoading] = useState(false);

  const subtotal = useMemo(
    () => cart.reduce((sum, item) => sum + item.unitPrice * item.qty, 0),
    [cart]
  );

  const total = subtotal + (cart.length > 0 ? DELIVERY_FEE : 0);

  const totalItems = useMemo(
    () => cart.reduce((s, i) => s + i.qty, 0),
    [cart]
  );

const changeQty = (id: string, delta: number) => {
  setCart((prev) =>
    prev
      .map((item) =>
        item.id === id ? { ...item, qty: Math.max(0, item.qty + delta) } : item
      )
      .filter((item) => item.qty > 0)
  );
};

// ÜRÜN SİLME FONKSİYONU – Sağ üst X için
const removeItem = (id: string) => {
  setCart((prev) => prev.filter((item) => item.id !== id));
};












  const formatCardNumber = (v: string) => {
    const digits = v.replace(/\D+/g, "").slice(0, 16);
    const parts = digits.match(/.{1,4}/g);
    return parts ? parts.join(" ") : "";
  };

  const formatExpiry = (v: string) => {
    const digits = v.replace(/\D+/g, "").slice(0, 4);
    if (digits.length <= 2) return digits;
    return `${digits.slice(0, 2)}/${digits.slice(2)}`;
  };

  const openSheet = () => {
    if (cart.length === 0) {
      Alert.alert("Sepet boş", "İlk önce sepetine ürün ekle.");
      return;
    }
    setSheetVisible(true);
  };

  const closeSheet = () => {
    if (loading) return;
    setSheetVisible(false);
  };

  const handlePay = () => {
    if (!address || address.length < 5) {
      Alert.alert("Adres hatalı", "Lütfen geçerli bir adres gir.");
      return;
    }
    const raw = cardNumber.replace(/\s+/g, "");
    if (raw.length !== 16) {
      Alert.alert("Kart numarası hatalı", "16 haneli kart numarası gir.");
      return;
    }
    if (!/^\d{2}\/\d{2}$/.test(expiry)) {
      Alert.alert("Son kullanma tarihi hatalı", "MM/YY formatında gir.");
      return;
    }
    if (cvc.length !== 3) {
      Alert.alert("CVC hatalı", "3 haneli CVC gir.");
      return;
    }

    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setSheetVisible(false);
      Alert.alert(
        "Ödeme başarılı",
        "Sparişin onaylandı. DatlyFruit kuryesi yola çıktı 🚚"
      );
      // İstersen sepeti de boşalt:
      // setCart([]);
    }, 1000);
  };

  const renderItem = ({ item }: { item: CartItem }) => {
    const lineTotal = item.unitPrice * item.qty;

    return (
   <View style={styles.itemCard}>

  {/* Sağ üst X butonu */}
<TouchableOpacity
  style={styles.deleteBtn}
  onPress={() => removeItem(item.id)}
  activeOpacity={0.7}
>
  <Ionicons name="close" size={16} color="#fff" />
</TouchableOpacity>


  <View style={styles.itemRow}>
    <View style={styles.itemIcon}>
      <Text style={styles.itemEmoji}>🍎</Text>
    </View>

    <View style={{ flex: 1 }}>
      <Text style={styles.itemName} numberOfLines={1}>
        {item.name}
      </Text>
      <Text style={styles.itemDetail} numberOfLines={1}>
        {item.detail}
      </Text>

      <View style={styles.itemBottomRow}>
        <View>
          <Text style={styles.itemPrice}>
            {item.unitPrice.toFixed(2)} TMT
          </Text>
          <Text style={styles.itemLineTotal}>
            Toplam: {lineTotal.toFixed(2)} TMT
          </Text>
        </View>

        <View style={styles.qtyRow}>
          <TouchableOpacity
            style={styles.qtyBtn}
            onPress={() => changeQty(item.id, -1)}
          >
            <Ionicons name="remove" size={16} color="#0F172A" />
          </TouchableOpacity>

          <Text style={styles.qtyText}>{item.qty}</Text>

          <TouchableOpacity
            style={styles.qtyBtn}
            onPress={() => changeQty(item.id, +1)}
          >
            <Ionicons name="add" size={16} color="#0F172A" />
          </TouchableOpacity>
        </View>
      </View>

    </View>
  </View>
</View>

    );
  };

  return (
    <View style={styles.root}>
      <StatusBar barStyle="light-content" backgroundColor="#001A3A" />

      {/* HEADER – İş Bankası tarzı */}
      <View style={styles.header}>
        <View style={styles.headerRow}>
          <View style={styles.headerLeft}>
            <TouchableOpacity
              style={styles.backBtn}
              onPress={onBack}
              activeOpacity={0.9}
            >
              <Ionicons name="chevron-back" size={18} color="#E5E7EB" />
            </TouchableOpacity>
            <View>
              <Text style={styles.headerSubtitle}>DatlyFruit • Sepet</Text>
              <Text style={styles.headerTitle}>Sepetiniz</Text>
            </View>
          </View>

          <View style={styles.headerRight}>
            <View style={styles.secureChip}>
              <Ionicons
                name="shield-checkmark-outline"
                size={14}
                color="#BBF7D0"
              />
              <Text style={styles.secureChipText}>Güvenli ödeme</Text>
            </View>
          </View>
        </View>

        {/* Mini adım barı */}
        <View style={styles.stepRow}>
          <Text style={[styles.stepText, styles.stepTextActive]}>
            1 • Sepet
          </Text>
          <View style={styles.stepLineBg}>
            <View style={styles.stepLineFill} />
          </View>
          <Text style={styles.stepText}>2 • Ödeme</Text>
          <Text style={styles.stepText}>3 • Teslimat</Text>
        </View>
      </View>

      {/* BODY */}
      <View style={styles.body}>
        {/* Info banner */}
        <View style={styles.infoBanner}>
          <Ionicons name="bicycle-outline" size={18} color="#0284C7" />
          <View style={{ marginLeft: 8, flex: 1 }}>
            <Text style={styles.infoTitle}>Gün içi teslimat</Text>
            <Text style={styles.infoText}>
              {subtotal >= 150
                ? "150 TMT üzeri siparişlerde teslimat ücretsiz."
                : `150 TMT üzeri ücretsiz. Şu an ${subtotal.toFixed(
                    2
                  )} TMT tutarında.`}
            </Text>
          </View>
        </View>

        {/* SEPET */}
        {cart.length === 0 ? (
          <View style={styles.emptyCard}>
            <Ionicons name="cart-outline" size={28} color="#9CA3AF" />
            <Text style={styles.emptyTitle}>Sepetiniz boş</Text>
            <Text style={styles.emptyText}>
              Anasayfadan ürün seçerek sepetinizi oluşturabilirsiniz.
            </Text>
          </View>
        ) : (
          <FlatList
            data={cart}
            keyExtractor={(i) => i.id}
            renderItem={renderItem}
            showsVerticalScrollIndicator={false}
            contentContainerStyle={{ paddingBottom: 12 }}
          />
        )}

        {/* ÖZET */}

      </View>

      {/* ALT BOTTOM BAR */}
      <View style={styles.bottomBar}>
        <View style={styles.bottomLeft}>
          <Text style={styles.bottomLabel}>Ödenecek tutar</Text>
          <Text style={styles.bottomAmount}>{total.toFixed(2)} TMT</Text>
        </View>
        <TouchableOpacity
          style={styles.bottomBtn}
          activeOpacity={0.9}
          onPress={openSheet}
        >
          <Ionicons name="lock-closed-outline" size={16} color="#E0F2FE" />
          <Text style={styles.bottomBtnText}>Ödeme adımına geç</Text>
        </TouchableOpacity>
      </View>

      {/* ÖDEME SHEET */}
      <Modal
        visible={sheetVisible}
        transparent
        animationType="slide"
        onRequestClose={closeSheet}
      >
        <KeyboardAvoidingView
          style={styles.sheetRoot}
          behavior={Platform.OS === "ios" ? "padding" : undefined}
        >
          <TouchableOpacity
            style={styles.sheetBackdrop}
            activeOpacity={1}
            onPress={closeSheet}
          />
          <View style={styles.sheet}>
            <View style={styles.sheetHandle} />

            {/* Basit kart preview */}
      

            {/* FORM */}
            <View style={styles.form}>
             
           

              <Text style={styles.formTitle}>Kart bilgileri</Text>

              <TextInput
                style={styles.input}
                placeholder="Kart numarası"
                placeholderTextColor="#9CA3AF"
                keyboardType="numeric"
                maxLength={19}
                value={cardNumber}
                onChangeText={(t) => setCardNumber(formatCardNumber(t))}
              />

              <View style={styles.formRow}>
                <TextInput
                  style={[styles.input, styles.inputHalf]}
                  placeholder="MM/YY"
                  placeholderTextColor="#9CA3AF"
                  keyboardType="numeric"
                  maxLength={5}
                  value={expiry}
                  onChangeText={(t) => setExpiry(formatExpiry(t))}
                />
                <TextInput
                  style={[styles.input, styles.inputHalf]}
                  placeholder="CVC"
                  placeholderTextColor="#9CA3AF"
                  keyboardType="numeric"
                  maxLength={3}
                  secureTextEntry
                  value={cvc}
                  onChangeText={setCvc}
                />
              </View>

              <View style={styles.secureRow}>
                <Ionicons
                  name="shield-checkmark-outline"
                  size={16}
                  color="#16A34A"
                />
                <Text style={styles.secureText}>
                  Demo arayüz — gerçek banka entegrasyonu yok, sadece UI.
                </Text>
              </View>
            </View>

            {/* SHEET BUTTONS */}
            <View style={styles.sheetButtons}>
              <TouchableOpacity
                style={styles.sheetCancel}
                onPress={closeSheet}
                disabled={loading}
              >
                <Text style={styles.sheetCancelText}>Vazgeç</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.sheetConfirm}
                onPress={handlePay}
                disabled={loading}
              >
                <Text style={styles.sheetConfirmText}>
                  {loading
                    ? "Ödeme yapılıyor..."
                    : `Ödemeyi tamamla • ${total.toFixed(2)} TMT`}
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </KeyboardAvoidingView>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: "#001A3A", // İş Bankası laciverti
  },

  /* HEADER */
  header: {
    paddingTop: 40,
    paddingBottom: 14,
    paddingHorizontal: 16,
  },
  headerRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  headerLeft: {
    flexDirection: "row",
    alignItems: "center",
  },
  backBtn: {
    width: 32,
    height: 32,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: "rgba(148,163,184,0.5)",
    justifyContent: "center",
    alignItems: "center",
    marginRight: 10,
  },
  headerSubtitle: {
    fontSize: 11,
    color: "#9CA3AF",
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: "800",
    color: "#E5E7EB",
  },
  headerRight: {
    alignItems: "flex-end",
  },
  secureChip: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    backgroundColor: "rgba(15,118,110,0.15)",
    borderWidth: 1,
    borderColor: "rgba(34,197,94,0.5)",
  },
  secureChipText: {
    fontSize: 11,
    color: "#DCFCE7",
    marginLeft: 4,
    fontWeight: "600",
  },

  stepRow: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 10,
  },
  stepText: {
    fontSize: 11,
    color: "#64748B",
  },
  stepTextActive: {
    color: "#E5E7EB",
    fontWeight: "700",
  },
  stepLineBg: {
    flex: 1,
    height: 3,
    borderRadius: 999,
    backgroundColor: "rgba(15,23,42,0.7)",
    marginHorizontal: 8,
    overflow: "hidden",
  },
  stepLineFill: {
    height: 3,
    width: "60%",
    backgroundColor: "#22C55E",
  },

  /* BODY */
  body: {
    flex: 1,
    backgroundColor: "#F3F4F6",
    borderTopLeftRadius: 22,
    borderTopRightRadius: 22,
    paddingHorizontal: 14,
    paddingTop: 12,
    paddingBottom: 80,
  },

  infoBanner: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#E0F2FE",
    borderRadius: 14,
    padding: 10,
    marginBottom: 8,
  },
  infoTitle: {
    fontSize: 13,
    fontWeight: "700",
    color: "#0F172A",
  },
  infoText: {
    fontSize: 11,
    color: "#4B5563",
    marginTop: 1,
  },

  emptyCard: {
    marginTop: 18,
    borderRadius: 18,
    backgroundColor: "#FFFFFF",
    padding: 24,
    alignItems: "center",
  },
  emptyTitle: {
    marginTop: 8,
    fontSize: 15,
    fontWeight: "700",
    color: "#111827",
  },
  emptyText: {
    marginTop: 4,
    fontSize: 12,
    color: "#6B7280",
    textAlign: "center",
  },

  itemCard: {
    borderRadius: 16,
    backgroundColor: "#FFFFFF",
    padding: 12,
    marginTop: 8,
    borderWidth: 1,
    borderColor: "#E5E7EB",
  },
  itemRow: {
    flexDirection: "row",
  },
  itemIcon: {
    width: 52,
    height: 52,
    borderRadius: 16,
    backgroundColor: "#EFF6FF",
    justifyContent: "center",
    alignItems: "center",
    marginRight: 10,
  },
  itemEmoji: {
    fontSize: 24,
  },
  itemName: {
    fontSize: 15,
    fontWeight: "600",
    color: "#111827",
  },
  itemDetail: {
    fontSize: 11,
    color: "#6B7280",
    marginTop: 2,
  },
  itemBottomRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-end",
    marginTop: 8,
  },
  itemPrice: {
    fontSize: 12,
    color: "#6B7280",
  },
  itemLineTotal: {
    fontSize: 13,
    fontWeight: "700",
    color: "#0F172A",
    marginTop: 2,
  },
  qtyRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  qtyBtn: {
    width: 30,
    height: 30,
    borderRadius: 12,
    backgroundColor: "#E5E7EB",
    justifyContent: "center",
    alignItems: "center",
  },
  qtyText: {
    minWidth: 26,
    textAlign: "center",
    fontSize: 14,
    fontWeight: "700",
    color: "#0F172A",
    marginHorizontal: 4,
  },

  summaryCard: {
    marginTop: 12,
    borderRadius: 18,
    backgroundColor: "#FFFFFF",
    padding: 12,
    borderWidth: 1,
    borderColor: "#E5E7EB",
  },
  summaryHeaderRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 6,
  },
  summaryTitle: {
    fontSize: 12,
    color: "#6B7280",
  },
  summarySub: {
    fontSize: 11,
    color: "#9CA3AF",
  },
  summaryTotal: {
    fontSize: 18,
    fontWeight: "800",
    color: "#111827",
  },
  summaryRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 4,
  },
  summaryLabel: {
    fontSize: 12,
    color: "#6B7280",
  },
  summaryValue: {
    fontSize: 13,
    color: "#111827",
    fontWeight: "600",
  },

  /* BOTTOM BAR */
  bottomBar: {
    position: "absolute",
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: 16,
    paddingTop: 8,
    paddingBottom: 14,
    backgroundColor: "#FFFFFF",
    borderTopWidth: 1,
    borderTopColor: "#E5E7EB",
    flexDirection: "row",
    alignItems: "center",
  },
  bottomLeft: {
    flex: 1,
  },
  bottomLabel: {
    fontSize: 11,
    color: "#6B7280",
  },
  bottomAmount: {
    fontSize: 17,
    fontWeight: "800",
    color: "#111827",
  },
  bottomBtn: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 18,
    paddingVertical: 10,
    borderRadius: 999,
    backgroundColor: "#0B63CE",
    marginLeft: 10,
  },
  bottomBtnText: {
    fontSize: 13,
    fontWeight: "700",
    color: "#E0F2FE",
    marginLeft: 6,
  },

  /* SHEET */
  sheetRoot: {
    flex: 1,
    justifyContent: "flex-end",
  },
  sheetBackdrop: {
    flex: 1,
    backgroundColor: "rgba(15,23,42,0.55)",
  },
  sheet: {
    backgroundColor: "#FFFFFF",
    borderTopLeftRadius: 22,
    borderTopRightRadius: 22,
    paddingHorizontal: 16,
    paddingTop: 8,
    paddingBottom: 16,
  },
  sheetHandle: {
    width: 40,
    height: 4,
    borderRadius: 999,
    backgroundColor: "#E5E7EB",
    alignSelf: "center",
    marginBottom: 10,
  },
  cardPreview: {
    borderRadius: 16,
    padding: 14,
    backgroundColor: "#0F172A",
    marginBottom: 12,
  },
  cardPreviewBrand: {
    fontSize: 12,
    color: "#BFDBFE",
    marginBottom: 10,
    fontWeight: "600",
  },
  cardPreviewNumber: {
    fontSize: 18,
    letterSpacing: 2,
    color: "#E5E7EB",
    marginBottom: 12,
  },
  cardPreviewRow: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  cardPreviewLabel: {
    fontSize: 10,
    color: "#9CA3AF",
  },
  cardPreviewValue: {
    fontSize: 12,
    color: "#E5E7EB",
    fontWeight: "700",
    marginTop: 2,
  },






  
/* FORM KUTUSU – BANKA KALİTESİ */
form: {
  marginTop: 14,
  padding: 20,
  borderRadius: 20,

  backgroundColor: "#F9FAFB",
  borderWidth: 1.4,
  borderColor: "#D0D5DD",

  shadowColor: "#0F172A",
  shadowOpacity: 0.06,
  shadowOffset: { width: 0, height: 4 },
  shadowRadius: 10,
},

/* BAŞLIK – Ciddi & kurumsal */
formTitle: {
  fontSize: 15,
  color: "#1E293B",
  marginTop: 12,
  marginBottom: 6,
  fontWeight: "800",
  letterSpacing: 0.4,
},

/* INPUT – Premium banka girişi */
input: {
  borderRadius: 14,
  borderWidth: 1.8,
  borderColor: "#CBD5E1",
  backgroundColor: "#FFFFFF",

  paddingHorizontal: 16,
  paddingVertical: 14,

  fontSize: 15,
  color: "#0F172A",
  marginBottom: 14,

  shadowColor: "#000",
  shadowOpacity: 0.04,
  shadowRadius: 6,
  shadowOffset: { width: 0, height: 3 },
},

/* Yan yana MM/YY ve CVC */
formRow: {
  flexDirection: "row",
  justifyContent: "space-between",
  marginBottom: 12,
},

inputHalf: {
  flex: 1,
  marginHorizontal: 5,
},

/* GÜVENLİK BİLGİSİ (İşCep Stili Uyarı Alanı) */
secureRow: {
  flexDirection: "row",
  alignItems: "center",

  padding: 14,
  marginTop: 14,

  borderRadius: 16,
  backgroundColor: "#F0FDF4",
  borderWidth: 1.6,
  borderColor: "#86EFAC",

  shadowColor: "#000",
  shadowOpacity: 0.05,
  shadowRadius: 8,
  shadowOffset: { width: 0, height: 3 },
},

secureText: {
  fontSize: 13,
  color: "#166534",
  marginLeft: 10,
  fontWeight: "700",
  lineHeight: 18,
  flex: 1,
},

/* BOTTOM BUTTONS */
sheetButtons: {
  flexDirection: "row",
  marginTop: 22,
},

/* İptal – Kurumsal gri banka butonu */
sheetCancel: {
  flex: 1,
  marginRight: 12,
  borderRadius: 999,
  borderWidth: 1.4,
  borderColor: "#D0D5DD",
  backgroundColor: "#FFFFFF",

  paddingVertical: 13,
  alignItems: "center",
  justifyContent: "center",

  shadowColor: "#000",
  shadowOpacity: 0.05,
  shadowRadius: 8,
  shadowOffset: { width: 0, height: 3 },
},

sheetCancelText: {
  fontSize: 14,
  fontWeight: "700",
  color: "#475569",
},

/* ÖDEME – IsBank “mavi/teal finans” tonu */
sheetConfirm: {
  flex: 1.8,
  borderRadius: 999,
  backgroundColor: "#0D6EFD", // İşCep mavisi

  alignItems: "center",
  justifyContent: "center",
  paddingVertical: 13,

  shadowColor: "#0D6EFD",
  shadowOpacity: 0.22,
  shadowRadius: 14,
  shadowOffset: { width: 0, height: 4 },
},

sheetConfirmText: {
  fontSize: 15,
  fontWeight: "900",
  color: "#F8FAFC",
  letterSpacing: 0.3,
  textAlign: "center",
},
deleteBtn: {
  position: "absolute",
  top: 6,
  right: 6,
  width: 24,
  height: 24,
  borderRadius: 12,
  backgroundColor: "#DC2626",
  justifyContent: "center",
  alignItems: "center",
  zIndex: 10,
},

});
